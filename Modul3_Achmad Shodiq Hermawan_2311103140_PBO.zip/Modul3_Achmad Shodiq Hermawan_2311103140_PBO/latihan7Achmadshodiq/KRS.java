/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan7Achmadshodiq;

/**
 *
 * @author User
 */
interface KRS {
    void tambahMatakuliah (Matakuliah mk);
    void hapusMatakuliah (Matakuliah mk);
}
