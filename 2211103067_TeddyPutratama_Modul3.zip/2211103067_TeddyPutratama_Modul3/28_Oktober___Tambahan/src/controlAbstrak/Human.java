/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlAbstrak;

/**
 *
 * @author ACER
 */
public class Human extends LivingThing {
    @Override 
    public void walk(){
        System.out.println("Berjalan dengan dua kaki");
    }
    public void breathe(){
        System.out.println("Bernafas dengan paru paru");
    }
    
}
