
package controlAbstrak;

/**
 2211103067
 Teddy Putratama
 * 07C
 */
public class Main {
   public static void main(String[] args) {
       LivingThing human = new Human();
       LivingThing dog = new Dog();
       
       human.eat();
       human.sleep();
       human.walk();
       human.breathe();
       
       dog.eat();
       dog.sleep();
       dog.walk();
       dog.breathe();
   }
           
}
