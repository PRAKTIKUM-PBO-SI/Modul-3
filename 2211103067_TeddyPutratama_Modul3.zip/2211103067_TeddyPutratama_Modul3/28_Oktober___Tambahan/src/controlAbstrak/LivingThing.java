
package controlAbstrak;

/**
 *
 * @author ACER
 */
public abstract class LivingThing {
    public void eat(){
        System.out.println("Memakan...");
    }
    public void sleep(){
        System. out.println("Tertidur...");
    }
    
    public abstract void walk();
    public abstract void breathe();
    
}
