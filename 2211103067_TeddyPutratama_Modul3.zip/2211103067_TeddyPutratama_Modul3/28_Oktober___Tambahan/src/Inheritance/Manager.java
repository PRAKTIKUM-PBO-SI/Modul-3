/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inheritance;

/**
 *
 * @author ACER
 */
class Manager extends Employee {

    private String alamat;

    public Manager(String nama, String s) {
        /memanggil konstruktor employee/
        super(nama);
        alamat = s;
    }

    public void tampilAlamat() {
        /menginisialisasi variabel departemen yang ada pada superclass/
        super.departemen = "Personalia";
        /memanggil Method tampilNama() yang ada pada superclass/
        super.tampilNama();
        /menampilkan variabel departemen yang telah diinisialisasi/
        System.out.println("alamat : " + alamat);
        System.out.println("departemen : " + super.departemen);
    }
}