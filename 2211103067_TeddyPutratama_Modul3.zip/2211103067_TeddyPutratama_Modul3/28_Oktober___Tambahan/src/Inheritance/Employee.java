
package Inheritance;

/**
 *
 * @author ACER
 */
class Employee {

    private String name;
    String departemen;

    public Employee(String s) {
        name = s;
    }

    public void tampilNama() {
        System.out.println("nama : " + name);
    }
