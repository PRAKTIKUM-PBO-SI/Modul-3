
package kendaraan;

/**
 Teddy Putratama
2211103067
07C
 */
public class Kendaraan {
 int roda;
 
 Kendaraan(int roda){
     this.roda = roda;
    }
 void bergerak (){
     System.out.println("Kendaraan Bergerak");
    }
}
