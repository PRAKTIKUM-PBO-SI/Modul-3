
package kendaraan;

/**
 *
 * @author ACER
 */
class Mobil extends Kendaraan {
    Mobil (){
        super(4); // mobil memiliki 4 roda
    }
    @Override
    void bergerak(){
        System.out.println("Mobil Bergerak Dengan Roda " + roda );
    }
}
