
package kendaraan;

/**
 *
 * @author ACER
 */
public class Main {
   public static void main(String[] args ){
       Mobil mobil = new Mobil();
       Motor motor = new Motor();
       
       mobil.bergerak();
       motor.bergerak();
   }
    
}
