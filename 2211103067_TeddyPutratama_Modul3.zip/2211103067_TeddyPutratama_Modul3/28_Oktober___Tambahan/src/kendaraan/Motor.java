
package kendaraan;

/**
 2211103067
 Teddy Putratama
 07C
*/
class Motor extends Kendaraan{
    Motor(){
        super(2); // motor memiliki 2 roda
    }
    
    @Override
    void bergerak(){
        System.out.println("Motor Bergerak dengan roda " + roda );
    }
}
